package com.example.utility.utilityapp;

import android.media.audiofx.DynamicsProcessing;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import java.text.DecimalFormat;

public class Length extends AppCompatActivity {
    private static DecimalFormat df = new DecimalFormat("#,##0.00");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_length);

        final EditText length = (EditText) findViewById(R.id.editTextInputUserL);
        final TextView displayL = (TextView) findViewById(R.id.textView);
        final RadioButton meters2feet = (RadioButton) findViewById(R.id.m2f);
        final RadioButton feet2meters = (RadioButton) findViewById(R.id.f2m);
        final Button submitlength = (Button) findViewById(R.id.btnSubmitLength);
        submitlength.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double valueL = Double.valueOf(length.getText().toString());
                if (meters2feet.isChecked())
                    valueL = Equations.meters2feet(valueL);
                else
                    valueL = Equations.feet2meters(valueL);
                String valueF2M = df.format(valueL);
                displayL.setText(valueF2M);
            }
        });



    }
}
