package com.example.utility.utilityapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;


import java.util.prefs.PreferenceChangeEvent;

import static android.widget.Toast.makeText;


public class MainActivity extends AppCompatActivity {

    private int lengthLong = Toast.LENGTH_LONG;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void onBtnClick(View view){
        if(view.getId()==R.id.btnTemp)
        {
            Intent i = new Intent(MainActivity.this, Temperature.class);
            startActivity(i);
        }

    }
    public void onBtnClickL(View view){
        if(view.getId()==R.id.btnL)
        {
            Intent i = new Intent(MainActivity.this, Length.class);
            startActivity(i);
        }

    }
    public void onBtnClickW(View view){
        if(view.getId()==R.id.btnW)
        {
            Intent i = new Intent(MainActivity.this, Weight.class);
            startActivity(i);
        }

    }
    public void onBtnClickSettings(View view){
        if(view.getId()==R.id.btnSettings) {
            Intent i = new Intent(this, SettingsActivity.class);
            startActivity(i);
        }
    }



    }
