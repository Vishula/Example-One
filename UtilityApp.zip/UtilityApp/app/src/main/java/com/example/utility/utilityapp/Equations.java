package com.example.utility.utilityapp;

public class Equations {
    public static double celcius2farenheit (double c){

        return (1.8*c)+32;

    }
    public static double farenheit2celcius (double f){

        return (f-32)*5/9;
    }
    public static double meters2feet (double meter){
        return (meter/3.28);

    }
    public static double feet2meters (double feet){
        return (feet*3.28);
    }
    public static double kg2pound (double kg){
        return (kg*2.2);
    }
    public static double pound2kg (double p){
        return (p/2.2);
    }
}
