package com.example.utility.utilityapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import java.text.DecimalFormat;

public class Weight extends AppCompatActivity {
    private static DecimalFormat df = new DecimalFormat("#,##0.00");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight);
        final EditText weight = (EditText) findViewById(R.id.editTextInputUserW);
        final TextView displayW = (TextView) findViewById(R.id.textViewW);
        final RadioButton kilo2pound = (RadioButton) findViewById(R.id.k2p);
        final RadioButton pound2kilo = (RadioButton) findViewById(R.id.p2k);
        final Button submitweight = (Button) findViewById(R.id.btnSubmitW);

        submitweight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double valueW = Double.valueOf(weight.getText().toString());
                if (kilo2pound.isChecked())
                    valueW = Equations.kg2pound(valueW);
                else
                    valueW = Equations.pound2kg(valueW);
                String valueP2KG = df.format(valueW);
                displayW.setText(valueP2KG);
            }
        });

    }

}
