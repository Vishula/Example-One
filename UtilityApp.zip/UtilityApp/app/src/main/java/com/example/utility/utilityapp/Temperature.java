package com.example.utility.utilityapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import java.text.DecimalFormat;


public class Temperature extends AppCompatActivity {
    private static DecimalFormat df = new DecimalFormat("#,##0.00");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperature);
        final EditText tempe = (EditText) findViewById(R.id.editTextInputUserT);
        final TextView displayT = (TextView) findViewById(R.id.textViewTemp);
        final RadioButton cel2far = (RadioButton) findViewById(R.id.c2f);
        final RadioButton far2cel = (RadioButton) findViewById(R.id.f2c);
        final Button submittemp = (Button) findViewById(R.id.btnSubmitTemp);

        submittemp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double valueT = Double.valueOf(tempe.getText().toString());

                if (far2cel.isChecked())
                    valueT=Equations.farenheit2celcius(valueT);
                else
                    valueT=Equations.celcius2farenheit(valueT);
                String valueC2F = df.format(valueT);
                displayT.setText(valueC2F);
            }
        });
    }

//    public void onBtnClickC(View view) {
////        EditText userInput = findViewById(R.id.editTextInputUser);
//////        TextView userOutput = findViewById(R.id.textViewTemp);
//////        String userInputToString = userInput.getText().toString();
//////        double userTemp = Double.parseDouble(userInputToString);
//////        double faren = ((userTemp -32) *5)/9;
//////        userOutput.setText(Double.toString(faren));
//        EditText userInput = (EditText) findViewById(R.id.editTextInputUser);
//        TextView userOutput = (TextView) findViewById(R.id.textViewTemp);
//        int celcius = Integer.parseInt(userInput.getText().toString());
//        double calculateF = (1.8*celcius)+32;
//        userOutput.setText(String.format(String.valueOf(calculateF)));
//    }
}
